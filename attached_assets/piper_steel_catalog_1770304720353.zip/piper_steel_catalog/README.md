# Piper Steel Catalog - E-commerce Starter Kit

Template for building product catalog sites with cart and admin functionality.

**Note:** Piper Steel is not a real company. This is a demo template.

## Features

- Product catalog with filtering and sorting
- Shopping cart with localStorage persistence
- Product detail modal
- Admin panel for adding/removing products (password: "steelsecure")
- Auto-scrolling featured products section
- Responsive design

## Use Case

Clone this template for building product catalog sites for small businesses. Includes core e-commerce UI patterns without backend dependencies.

## Tech Stack

- Vanilla JavaScript
- localStorage for data persistence
- CSS Grid for product layouts
- Modal UI pattern

## Getting Started

1. Modify `Inventory.js` with your product data
2. Update `siteContent.js` for site branding
3. Customize styles in `style.css`
4. Change admin password in `main.js` (line 174)

## Template License

Free to use and modify for your projects.
