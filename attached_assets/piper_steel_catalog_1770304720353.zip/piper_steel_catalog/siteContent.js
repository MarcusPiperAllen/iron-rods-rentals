// ===== siteContent.js =====
// Holds the hero and about section content for homepage

const contentData = {
  heroText: "Welcome to Piper Steel – where quality meets strength.",
  aboutText: "We supply top-tier steel products for contractors, builders, and DIY pros alike."
};
