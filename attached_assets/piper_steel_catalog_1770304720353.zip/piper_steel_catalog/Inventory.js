// ===== steelInventory.js =====
// Array of steel product data for use in homepage product cards

const defaultProducts = [
  {
    name: "16 Gauge Pipe – 2\" x 10ft",
    type: "Pipe",
    price: 42.50,
    specs: "Cold-rolled, galvanized, structural use",
    stock: 48,
    img: "https://picsum.photos/300/200?random=3"
  },
  {
    name: "Galvanized Purlin – Z-Shape 6\" x 20ft",
    type: "Purlin",
    price: 78.99,
    specs: "Z-channel, 16 gauge, punched",
    stock: 32,
    img: "https://picsum.photos/300/200?random=1"
  },
  {
    name: "Steel Angle – 2\" x 2\" x 1/4\" x 10ft",
    type: "Angle",
    price: 36.75,
    specs: "Mild steel, equal leg",
    stock: 75,
    img: "https://picsum.photos/300/200?random=2"
  },
  {
    name: "Square Tubing – 2\" x 2\" x 1/8\" x 24ft",
    type: "Tubing",
    price: 92.10,
    specs: "Black steel, structural-grade",
    stock: 20,
    img: "https://picsum.photos/300/200?random=4"
  },
  {
    name: "Heavy Steel Plate 1\"",
    type: "Plate",
    price: 150.00,
    specs: "Grade A36, 48\" x 96\"",
    stock: 12,
    img: "https://picsum.photos/300/200?random=5"
  }
];

// Load from localStorage or fallback to default
let steelProducts = JSON.parse(localStorage.getItem("steelProducts"));

if (!steelProducts || !Array.isArray(steelProducts)) {
  steelProducts = defaultProducts;
  localStorage.setItem("steelProducts", JSON.stringify(steelProducts));
}

