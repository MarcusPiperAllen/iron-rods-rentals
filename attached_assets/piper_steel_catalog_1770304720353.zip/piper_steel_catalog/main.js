// =======================
//  Setup DOM References
// =======================
const container = document.getElementById("products-container");
const cartPanel = document.getElementById("cart-panel");
const cartContainer = document.getElementById("cart-container");
const cartCountSpan = document.getElementById("cart-count");
const cartList = document.getElementById("cart-items");
const productModal = document.getElementById("product-modal");
const modalTitle = document.getElementById("modal-title");
const modalBody = document.getElementById("modal-body");
const closeModalBtn = document.querySelector(".close-button");


let cartCount = 0;
const cartItems = [];
const featuredProducts = steelProducts.slice(0, 6);
 let isAdmin = false;  // new flag

// ========================
// Toggle Cart Panel Logic
// ========================
cartContainer.addEventListener("click", () => {
  cartPanel.classList.remove("hidden");        // Ensure it's visible
  cartPanel.classList.toggle("show");          // Slide it in/out
});




// openProduct Modal
function openProductModal(product) {
  modalTitle.textContent = product.name;

  modalBody.innerHTML = `
    <p><strong>Type:</strong> ${product.type}</p>
    <p><strong>Specs:</strong> ${product.specs}</p>
    <p><strong>Price:</strong> $${product.price.toFixed(2)}</p>
    <p><strong>In Stock:</strong> ${product.stock}</p>
  `;

  productModal.classList.remove("hidden");
}


// ====================================
//  Render Products from steelProducts
// ====================================
steelProducts.forEach(renderProductCard);
// Featured container logic
  const featuredContainer = document.getElementById("featured-container");

featuredProducts.forEach(product => {
  const card = document.createElement("div");
  card.classList.add("product-card", "featured");

  card.innerHTML = `
    <h3>${product.name}</h3>
    <p><strong>Type:</strong> ${product.type}</p>
    <p><strong>Specs:</strong> ${product.specs}</p>
    <p><strong>Price:</strong> $${product.price.toFixed(2)}</p>
    <p><strong>In Stock:</strong> ${product.stock}</p>
  `;

  featuredContainer.appendChild(card);
});
  


 

// ============================
// Render Cart Item Display
// ============================
function renderCartItems() {
  const cartList = document.getElementById("cart-items");
  const cartTotal = document.getElementById("cart-total");
  cartList.innerHTML = ""; // Clear old items

  let total = 0;

  cartItems.forEach((item) => {
    const li = document.createElement("li");
    li.textContent = `${item.name} – $${item.price.toFixed(2)}`;
    cartList.appendChild(li);
    total += item.price;
  });

  cartTotal.textContent = total.toFixed(2);
}


//Render Product cards , this updates the product cards
function renderProductCard(product) {
  const card = document.createElement("div");
  card.classList.add("product-card");

  card.innerHTML = `
    <img src="${product.img || 'https://via.placeholder.com/300x200?text=No+Image'}" alt="${product.name}" class="product-img" />
    <h3>${product.name}</h3>
    <p><strong>Type:</strong> ${product.type}</p>
    <p><strong>Specs:</strong> ${product.specs}</p>
    <p><strong>Price:</strong> $${product.price.toFixed(2)}</p>
    <p><strong>In Stock:</strong> ${product.stock}</p>
    <button class="add-to-cart">Add to Cart</button>
    ${isAdmin ? '<button class="delete-product">Delete</button>' : ''}
  `;

  card.querySelector(".add-to-cart").addEventListener("click", () => {
    openProductModal(product);
  });

  if (isAdmin) {
    card.querySelector(".delete-product").addEventListener("click", () => {
      const index = steelProducts.indexOf(product);
      if (index > -1) {
        steelProducts.splice(index, 1);
        localStorage.setItem("steelProducts", JSON.stringify(steelProducts));
        card.remove();
      }
    });
  }

  container.appendChild(card);
}
function renderAllProducts() {
  container.innerHTML = "";            // Clear all current cards
  steelProducts.forEach(renderProductCard);  // Re-render with updated isAdmin logic
}






// =========================
// PRODUCT EDITOR LOGIC
// =========================
const editorForm = document.getElementById("product-editor");

editorForm.addEventListener("submit", (e) => {
  e.preventDefault();

  const name = document.getElementById("new-name").value.trim();
const type = document.getElementById("new-type").value.trim();
const specs = document.getElementById("new-specs").value.trim();
const price = parseFloat(document.getElementById("new-price").value);
const stock = parseInt(document.getElementById("new-stock").value);
const img = document.getElementById("new-img").value.trim();



  if (!name || !type || isNaN(price) || isNaN(stock)) {
    alert("Please fill out all required fields correctly.");
    return;
  }

  const newProduct = { name, type, specs, price, stock,img, userAdded: true };

  steelProducts.push(newProduct);
  localStorage.setItem("steelProducts", JSON.stringify(steelProducts));

  renderProductCard(newProduct); // Add it visually
  editorForm.reset(); // Clear the form
});
// toggle for editor 
// Toggle Editor Visibility
const adminToggleBtn = document.getElementById("admin-toggle");
const editorWrapper = document.getElementById("editor-wrapper");

adminToggleBtn.addEventListener("click", () => {
  const password = prompt("Enter admin password to edit products:");

  if (password === "steelsecure") {
     isAdmin = true;
    editorWrapper.classList.toggle("hidden");
     renderAllProducts(); // Re-render to show delete buttons
  } else {
    alert("Incorrect password. Access denied.");
  }
});

// ===========================
// Filter + Sort Functionality
// ===========================
const filterType = document.getElementById("filter-type");
const sortPrice = document.getElementById("sort-price");

filterType.addEventListener("change", applyFilters);
sortPrice.addEventListener("change", applyFilters);

function applyFilters() {
  const type = filterType.value;
  const sort = sortPrice.value;

  let filtered = [...steelProducts];

  if (type !== "all") {
    filtered = filtered.filter(p => p.type === type);
  }

  if (sort === "low-high") {
    filtered.sort((a, b) => a.price - b.price);
  } else if (sort === "high-low") {
    filtered.sort((a, b) => b.price - a.price);
  }

  renderFilteredProducts(filtered);
}

function renderFilteredProducts(filteredList) {
  container.innerHTML = ""; // Clear current products
  filteredList.forEach(renderProductCard);
}
// ==============================
// Auto-scroll Featured Section
// ==============================
window.addEventListener("DOMContentLoaded", () => {
  const featuredContainer = document.getElementById("featured-container");
  let scrollPaused = false;

  function autoScrollFeatured() {
    if (!scrollPaused) {
      featuredContainer.scrollBy({
        left: 1,
        behavior: "smooth"
      });
    }
  }

  featuredContainer.addEventListener("pointerdown", () => {
    scrollPaused = true;
  });

  let inactivityTimeout;
  featuredContainer.addEventListener("pointerup", () => {
    clearTimeout(inactivityTimeout);
    inactivityTimeout = setTimeout(() => {
      scrollPaused = false;
    }, 4000);
  });

  setInterval(autoScrollFeatured, 40);
});


closeModalBtn.addEventListener("click", () => {
  productModal.classList.add("hidden");
});


